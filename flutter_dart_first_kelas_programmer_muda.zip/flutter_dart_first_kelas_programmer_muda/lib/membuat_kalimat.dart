//soal nomor 1
//menggabungkatan kata menjadi sebuah kalimat

void main() {
  var word = 'Dart';
  var second = 'is';
  var third = 'awesome';
  var fourth = 'and';
  var fifth = 'i';
  var six = 'love';
  var seventh = 'it!';

  print([word, second, third, fourth, fifth, six, seventh]);
}
