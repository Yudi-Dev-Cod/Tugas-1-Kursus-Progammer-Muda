//pembagian

void main() {
  int angka1 = 50;
  int angka2 = 2;
  double hasilPembagian = angka1 / angka2;

  print('Hasil pembagian dari $angka1 dan $angka2 adalah $hasilPembagian');
}
