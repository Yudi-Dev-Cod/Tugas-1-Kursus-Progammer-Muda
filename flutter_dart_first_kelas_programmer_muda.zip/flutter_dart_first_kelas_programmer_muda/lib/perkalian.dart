//perkalian
//tugas 1 Soal Nomor 4
void main() {
  var angka1 = 45;
  var angka2 = 3;
  var hasilPerkalian = angka1 * angka2;

  print('Hasil perkalian dari $angka1 dan $angka2 adalah $hasilPerkalian');
}

//senang rasanya bisa menghasilkan perkalian dari belajar flutter dasar dan dart dasar
