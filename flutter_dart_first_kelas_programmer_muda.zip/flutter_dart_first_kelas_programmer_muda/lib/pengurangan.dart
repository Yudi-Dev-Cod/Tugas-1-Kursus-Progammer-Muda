//penguranga

void main() {
  int angka1 = 100;
  int angka2 = 20;
  int hasilPengurangan = angka1 - angka2;

  print('Hasil pengurangan dari $angka1 dan $angka2 adalah $hasilPengurangan');
}
