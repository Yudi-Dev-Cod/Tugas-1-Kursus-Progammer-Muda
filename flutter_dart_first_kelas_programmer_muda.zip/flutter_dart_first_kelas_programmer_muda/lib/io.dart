//buat input dinamis
//soal nomor 2
void main() {
  var namaDepan = 'Yudiono';
  var namaBelakang = 'Pratama';

  print('Hello, my name is $namaDepan $namaBelakang.');
}
