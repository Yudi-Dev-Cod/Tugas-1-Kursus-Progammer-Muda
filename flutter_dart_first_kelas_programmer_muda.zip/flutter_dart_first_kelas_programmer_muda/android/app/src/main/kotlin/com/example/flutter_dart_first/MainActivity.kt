package com.example.flutter_dart_first

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
